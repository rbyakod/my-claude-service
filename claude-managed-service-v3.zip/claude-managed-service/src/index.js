import { createServer } from 'http';
import { readFileSync }  from 'fs';
import { resolve }       from 'path';
import { config }        from './config.js';
import { logger }        from './logger.js';
import { agentStore }    from './agents.js';
import { handleHealth }  from './routes/health.js';
import { handleTasks }   from './routes/tasks.js';
import { handleAgents }  from './routes/agents.js';
import { handleEvents }  from './routes/events.js';

const dashboardPath = resolve(process.cwd(), 'public/dashboard.html');

const server = createServer(async (req, res) => {
  const urlParts = req.url.split('?')[0].split('/').filter(Boolean);
  const resource = urlParts[0];

  logger.debug('request', { method: req.method, url: req.url });

  if (resource === 'health')    return handleHealth(req, res);
  if (resource === 'tasks')     return handleTasks(req, res, urlParts);
  if (resource === 'agents')    return handleAgents(req, res, urlParts);
  if (resource === 'events')    return handleEvents(req, res);

  // Serve the dashboard at GET /dashboard
  if (req.method === 'GET' && (!resource || resource === 'dashboard')) {
    try {
      const html = readFileSync(dashboardPath);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Dashboard not found — is public/dashboard.html present?');
    }
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(config.port, () => {
  logger.info('my-service started', {
    port: config.port, logLevel: config.logLevel,
    dashboard: `http://localhost:${config.port}/dashboard`,
  });
});

// Prune long-dead agents every 60 seconds
setInterval(() => agentStore.pruneStale(), 60_000);

// Graceful shutdown — service managers send SIGTERM
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => { logger.info('server closed'); process.exit(0); });
});
process.on('SIGINT', () => { server.close(() => process.exit(0)); });
