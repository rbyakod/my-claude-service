import { agentStore } from '../agents.js';
import { logger }     from '../logger.js';

function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

async function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

export async function handleAgents(req, res, urlParts) {
  const method = req.method;
  const id     = urlParts[1]; // /agents/:id — urlParts is ['agents', id]

  try {
    // GET /agents
    if (method === 'GET' && !id) {
      return json(res, 200, agentStore.list());
    }

    // GET /agents/:id
    if (method === 'GET' && id) {
      const agent = agentStore.get(id);
      return agent ? json(res, 200, agent) : json(res, 404, { error: 'Agent not found' });
    }

    // POST /agents — register
    if (method === 'POST' && !id) {
      const body = await readBody(req);
      if (!body.id || typeof body.id !== 'string')
        return json(res, 400, { error: 'id is required and must be a string' });
      const agent = agentStore.register({
        id:         body.id.trim(),
        name:       body.name,
        capability: body.capability,
        metadata:   body.metadata,
      });
      return json(res, 201, agent);
    }

    // PATCH /agents/:id — update status / heartbeat
    if (method === 'PATCH' && id) {
      const body  = await readBody(req);
      const valid = ['idle', 'active', 'error'];
      if (body.status && !valid.includes(body.status))
        return json(res, 400, { error: `status must be one of: ${valid.join(', ')}` });
      const agent = agentStore.update(id, {
        ...(body.status      && { status:      body.status }),
        ...(body.currentTask !== undefined && { currentTask: body.currentTask }),
        ...(body.metadata    && { metadata:    body.metadata }),
      });
      return agent ? json(res, 200, agent) : json(res, 404, { error: 'Agent not found' });
    }

    // DELETE /agents/:id — deregister
    if (method === 'DELETE' && id) {
      const deleted = agentStore.delete(id);
      if (!deleted) return json(res, 404, { error: 'Agent not found' });
      res.writeHead(204); return res.end();
    }

    json(res, 405, { error: 'Method not allowed' });
  } catch (err) {
    logger.error('agents route error', { error: err.message });
    json(res, 500, { error: err.message });
  }
}
